package camila_practicalpart2;

public interface powerInt {
	double powerN(double b, double x);
}
