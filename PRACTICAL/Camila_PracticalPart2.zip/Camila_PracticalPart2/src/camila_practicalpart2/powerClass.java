package camila_practicalpart2;

public class powerClass implements powerInt {

	@Override
	public double powerN(double b, double x) {
		// TODO Auto-generated method stub
		
		 double r1=1;
		 
	     if(b >= 0 && x == 0)
	     
	        r1 =1;
	 
	     else if(b == 0 && x >= 1)
	 
	        r1=0;
	     else
	 
	       for(int i=1;i<=x;i++)
	       
	         r1 = r1 *b;
	 
	     return r1; 
	}

	
}
