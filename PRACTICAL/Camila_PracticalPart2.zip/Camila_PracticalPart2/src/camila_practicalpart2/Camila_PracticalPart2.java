/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package camila_practicalpart2;

import java.util.Scanner;

public class Camila_PracticalPart2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
    	Scanner in = new Scanner(System.in);
    	
    	powerClass result1 = new powerClass();
    	double base = 0, expo = 0;
		double res1 = result1.powerN(base, expo);
    	
    	System.out.printf("---- CAMILA, DEXTER B. PRACTICAL PART 2 ---- \n");
    	System.out.printf("Enter Base number: ");
    	base = in.nextInt();
        System.out.printf("Enter Exponent: ");
        expo = in.nextInt();
        System.out.println(base + "^" + expo + " = " + result1.powerN(base, expo));
                    
    }
}
